/*
 * gpio.h
 *
 *  Created on: Oct 30, 2024
 *      Author: ricar
 */

#ifndef DHT11_H_
#define DHT11_H_


#include "stm32f446xx.h"
#include "timer.h"

#define TEMP_MS (12 << 4)
#define TEMP_LS (8 << 4)
#define HUMID_MS (4 << 4)
#define HUMID_LS (0)

void PortSetup();
//uint16_t Poll_Sensor();
void Timer7Setup(void);


#endif /* DHT11_H_ */
