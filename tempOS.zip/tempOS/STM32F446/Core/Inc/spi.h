/*
 * spi.h
 *
 *  Created on: Nov 7, 2024
 *      Author: ricar
 */

#ifndef SPI_H_
#define SPI_H_

#include "stm32f4xx.h"

void SPISetup(void);
void SPISend(uint8_t val);

#endif /* SPI_H_ */
