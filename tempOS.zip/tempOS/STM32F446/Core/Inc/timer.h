/*
 * timer.c
 *
 *  Created on: Oct 30, 2024
 *      Author: ricar
 */

#ifndef TIMER_H_
#define TIMER_H_

#include "stm32f446xx.h"

void Timer6Setup();
void TimerSetup();
void start();
uint16_t stop();

void delay_mS(int mS);
void delay_uS(int uS);



#endif /* TIMER_C_ */
