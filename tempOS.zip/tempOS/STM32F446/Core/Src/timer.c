/*
 * timer.c
 *
 *  Created on: Nov 26, 2024
 *      Author: ricar
 */

#include "timer.h"
#include "FreeRTOS.h"

//blocking flag for delay implementation
volatile uint8_t UIF;

//set up timer to be used for implementing blocking delays
//one pulse mode: timer disables itself after reaching its interrupt
void Timer6Setup(void)
{
	RCC->APB1ENR |= RCC_APB1ENR_TIM6EN; //enable peripheral clock for TIM6

	TIM6->CR1 |= TIM_CR1_OPM | TIM_CR1_URS; //one pulse mode and disable UG interrupts

	TIM6->EGR |= TIM_EGR_UG; //force update on timer registers

	NVIC_EnableIRQ(TIM6_DAC_IRQn);
}


//sit in an idle state for however many milliseconds
void delay_mS(int mS)
{

	//prescale by 15999 to get 1 ms resolution
	TIM6->PSC = 15999;
	TIM6->ARR = (uint16_t)mS;
	TIM6->CNT = 0;

	//UARTTx(placeholder);

	//clear interrupt flags and force update timer registers
	TIM6->SR &= ~(TIM_SR_UIF);
	TIM6->DIER |= TIM_DIER_UIE;
	TIM6->EGR |= TIM_EGR_UG;

	//start count and wait for blocking flag to be set by timer compare interrupt
	TIM6->CR1 |= TIM_CR1_CEN;
	while(UIF == 0);

	//reset blocking flag
	UIF = 0;
}

//sit in an idle state for however many microseconds
void delay_uS(int uS)
{
	//prescale by 15 to get 1 us resolution
	TIM6->PSC = 15;
	TIM6->ARR = (uint16_t)uS;
	TIM6->CNT = 0;

	//clear interrupt flags and force update timer registers
	TIM6->SR &= ~(TIM_SR_UIF);
	TIM6->DIER |= TIM_DIER_UIE;
	TIM6->EGR |= TIM_EGR_UG;

	//start count and wait for blocking flag to be set by timer compare interrupt
	TIM6->CR1 |= TIM_CR1_CEN;
	while(UIF == 0);

	//reset blocking flag
	UIF = 0;
}

//interrupt for blocking timer
void TIM6_DAC_IRQHandler()
{
	traceISR_ENTER();
	//set blocking flag (TIM status register flag is cleared by interrupt and cannot be read by main code)
	UIF = 1;

	//disable timer interrupt to ensure it does not keep
	traceISR_EXIT();
	TIM6->SR &= ~TIM_SR_UIF;
}
