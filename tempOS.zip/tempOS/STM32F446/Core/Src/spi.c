/*
 * spi.c
 *
 *  Created on: Nov 26, 2024
 *      Author: ricar
 */

#include "spi.h"

void SPISetup(void)
/* Set up the GPIO pins and SPI settings for simplex comms at 250k baud */
{
	//enable peripheral clocks for SPI1 and GPIOB
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
	RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;

	//alternate functions for SPI pins (MOSI and SCK)
	//PB6 : Chip Select
	GPIOB->MODER |= (0b10 << 12);
	GPIOB->AFR[0] |= (5 << 24);
	GPIOB->OSPEEDR |= (0b11 << 12);

	//PA5 : SCLK
	//PA7 : MOSI
	//MISO unused in simplex comms
	GPIOA->MODER |= (0b10 << 10) | (0b10 << 14);
	GPIOA->AFR[0] |= (5 << 20) | (5 << 28);
	GPIOA->OSPEEDR |= (0b11 << 10) | (0b11 << 14);

    //master mode simplex (no MISO) 8-bit mode
	SPI1->CR1 |= SPI_CR1_BIDIOE | SPI_CR1_MSTR;
	//250k baud (16 MHz / 64)
	SPI1->CR1 |= (5 << 3);

	SPI1->CR2 |= SPI_CR2_SSOE;

	SPI1->CR1 |= SPI_CR1_SPE;
}

void SPISend(uint8_t val)
{
	//wait until tx buffer is empty in case of unfinished transfers
	while(!(SPI1->SR & SPI_SR_TXE));
	SPI1->DR = val;;
}

