/*
 * dht11.c
 *
 *  Created on: Nov 26, 2024
 *      Author: ricar
 */

#include "dht11.h"

void PortSetup(void)
{
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN; //enable clock for GPIO A

	EXTI->IMR |= EXTI_IMR_MR10;
	EXTI->RTSR |= EXTI_RTSR_TR10;
	EXTI->FTSR |= EXTI_FTSR_TR10;

	SYSCFG->EXTICR[2] = 0; //default, ensure PA pins are selected for interrupts

	NVIC_EnableIRQ(EXTI15_10_IRQn);


}

/*uint16_t Poll_Sensor(void)
{
	i_data = 0;
	// Disable Interrupts
	EXTI->IMR &= ~EXTI_IMR_MR10;
	EXTI->RTSR &= ~EXTI_RTSR_TR10;
	EXTI->FTSR &= ~EXTI_FTSR_TR10;

	// Take control of data wire
	GPIOA->MODER |= (1 << 20);

	// Wake up command to sensor to send data
	// pull signal low for 20 ms, then high for 40 us
	GPIOA->BSRR |= GPIO_BSRR_BR10;
	delay_mS(20);
	GPIOA->BSRR |= GPIO_BSRR_BS10;
	delay_uS(40);

	// Return control of data wire
	GPIOA->MODER &= ~(1 << 20);

	// Enable Interrupts
	EXTI->IMR |= EXTI_IMR_MR10;
	EXTI->RTSR |= EXTI_RTSR_TR10;
	EXTI->FTSR |= EXTI_FTSR_TR10;

	TIM7->CR1 |= TIM_CR1_CEN;

	//wait for sensor to finish outputting data
	while(i_data < 82);

	int k = 0;
	//converted data
	uint16_t data_c = 0;
	//data_c[1] = 0;
	//data_c[2] = 0;

	//parse the temp data into an 8bit number

	//note: we can ignore the first three entries, as it is the sensor's ACK signal
	for(k = 0; k < 16; k += 2)
	{
		if(data[k + 3] > 50)
		data_c |= 1 << (7 - (k >> 1));
	}
	//shifting data to make room for the next set
	data_c = data_c << 8;

	//parse the humidity data into an 8bit number
	for(k = 0; k < 16; k += 2)
	{
		if(data[k + 35] > 50)
		data_c |= 1 << (7 - (k >> 1));
	}

	return data_c;
}*/


void Timer7Setup(void)
{
	RCC->APB1ENR |= RCC_APB1ENR_TIM7EN;

	TIM7->CR1 |= TIM_CR1_URS; //disable UG interrupts

	TIM7->PSC = 83; //prescaler of 83 for 1 uS resolution

	TIM7->EGR |= TIM_EGR_UG;
}

//Interrupt that measures the data coming out of the DHT11 sensor
//for each bit, the sensor outputs a low stop bit then a variable-width pulse corresponding to 0 or 1
//stop bits are low signal held for 50 uS
//1 value bits are high signal held for ~75 uS
//0 value bits are high signal held for ~25 uS
