/*
 * spi.h
 *
 * Created: 11/8/2024 11:18:16 AM
 *  Author: ricar
 */ 


#ifndef SPI_H_
#define SPI_H_

void SPISetup();

#endif /* SPI_H_ */