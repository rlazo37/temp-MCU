/*
 * UART.h
 *
 * Created: 11/25/2024 12:33:47 PM
 *  Author: ricar
 */ 


#ifndef UART_H_
#define UART_H_

void UARTSetup(void);
void UARTSendchar(char character);
void UARTSend(const char * message);

void UARTSetup(void)
//defaults to 8 bits, 1 stop bit
{	
	UBRR0L = 12;
	UCSR0B |= (1 << TXEN0);
}

void UARTSendchar(char character)
{
	UDR0 = character;
	while(!(UCSR0A & (1<<UDRE0)));
}

void UARTSend(const char * message)
{
	for(int i = 0; message[i] != '\0'; i++)
		UARTSendchar(message[i]);
		
	return;
}



#endif /* UART_H_ */