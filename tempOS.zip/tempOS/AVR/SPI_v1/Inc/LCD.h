/*
 * IncFile1.h
 *
 * Created: 10/23/2024 3:00:07 PM
 *  Author: ricar
 */ 


#ifndef LCD_H_
#define LCD_H_

#include <stdbool.h>
#include <stdio.h>

void ClearDisplay(void);
void ReturnHome(void);
void EntryModeSet(bool ID, bool S);
void DisplayToggle(bool D, bool C, bool B);
void DisplayShift(bool SC, bool RL);
void FunctionSet(bool DL, bool N, bool F);
void FunctionSetINIT(void);
void SetCGRAM(uint8_t address);

uint8_t ReadRAM(void);

void SetDDRAM(uint8_t address);
void WriteRAM(char character);
void WriteLine(const char* message);
void WriteLineTop(const char* message);
void WriteLineBot(const char* message);

void ResetSequence(void);



#endif /* LCD_H_ */