/*
 * SPI_v1.c
 *
 * Created: 11/8/2024 11:17:57 AM
 * Author : ricar
 */ 

#define F_CPU 16000000L

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>

#include "Inc/LCD.h"
//#include "UART.h"
#include "Inc/spi.h"

void TimerSetup(void);

volatile uint16_t data_frame = 0;
volatile uint8_t received = 0;
volatile uint8_t cont_flag = 0;

char placeholder[64];

int main(void)
{
	sei();
	SREG |= (1 << 7);
	
	SPISetup();
	//UARTSetup();
	
	_delay_ms(500);
	
	ResetSequence();
	_delay_ms(50);
	ClearDisplay();
	_delay_ms(50);
	
	WriteLineTop("Waiting for data...");
	
	
	
	
	//char pholder[16];
	uint16_t temp_F = 0;
    /* Replace with your application code */
	
    while (1) 
    {
		while(cont_flag < 3);
		cont_flag = 0;
		ClearDisplay();
		_delay_ms(10);
		
		//sprintf(placeholder, "dataH: %u, dataL: %u, WHOLE:%u\n\r", (uint8_t)(data_frame >> 8), (uint8_t)(data_frame & 0xFF), data_frame);
		//UARTSend(placeholder);
		
		temp_F = (((data_frame >> 8) * 9) / 5) + 32;
		
		sprintf(placeholder, "Temp: %uC | %uF", (data_frame >> 8), temp_F);
		WriteLineTop(placeholder);
		
		sprintf(placeholder, "Humidity: %u%%", (data_frame & 0xFF));
		WriteLineBot(placeholder);
		//_delay_ms(2000);
		
		//ClearDisplay();
		//_delay_ms(15); 
    }
}

ISR(SPI_STC_vect)
{	
	cont_flag++;
	//received = SPSR;
	//received = SPDR;
	//sprintf(placeholder, "SPDR: %u\n\r", SPDR);
	//UARTSend(placeholder);
	data_frame &= ~((0xF) << ((SPDR & 0xF0) >> 4));
	data_frame |= ((SPDR & 0xF) << ((SPDR & 0xF0) >> 4));
}

