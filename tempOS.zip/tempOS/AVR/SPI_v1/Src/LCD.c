/*
 * LCD.c
 *
 * Created: 12/5/2024 11:23:25 AM
 *  Author: ricar
 */ 

#ifndef F_CPU
#define F_CPU 16000000UL
#endif

#include "../Inc/LCD.h"
#include <avr/io.h>
#include <util/delay.h>

#define ENABLE (1 << 4)
#define RS 2
#define RW 1


void ClearDisplay(void)
{
	PORTD = 1;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void ReturnHome(void)
{
	PORTD = 2;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void EntryModeSet(bool ID, bool S)
{
	PORTD = 4 | (ID << 1) | S;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void DisplayToggle(bool D, bool C, bool B)
{
	PORTD = 8 | (D << 2) | (C << 1) | B;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void DisplayShift(bool SC, bool RL)
{
	PORTD = 16 | (SC << 3) | (RL << 2);
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void FunctionSet(bool DL, bool N, bool F)
{
	PORTD = 32 | (DL << 4) | (N << 3) | (F << 2);
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void FunctionSetINIT(void)
{
	PORTD = 48;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void SetCGRAM(uint8_t address)
{
	PORTD = 64 | address;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

void SetDDRAM(uint8_t address)
{
	PORTD = 128 | address;
	PORTB &= ~3;
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_ms(1);
	PORTC &= ~ENABLE;

}

uint8_t ReadBusy(uint8_t address)
{
	DDRD = 0;
	PORTB = 5;
	uint8_t result = PIND;
	DDRD = 0xFE;
	return result;
}

void WriteRAM(char character)
{
	
	PORTD = (uint8_t)character;
	PORTB &= ~1;
	PORTB |= 2;
	
	_delay_us(1);
	PORTC |= ENABLE;
	_delay_us(100);
	PORTC &= ~ENABLE;
	
}

uint8_t ReadRAM(void)
{
	DDRD = 0;
	PORTB = RS | RW | ENABLE;
	_delay_us(1);
	uint8_t result = PIND;
	DDRD = 0xFE;
	return result;
}

void WriteLine(const char* message)
{
	static bool line = 0;
	
	if (line) SetDDRAM(0x40);
	else SetDDRAM(0x00);
	
	int i = 0;
	while(message[i] != 0 && i < 16)
	{
		WriteRAM(message[i]);
		//_delay_ms(100);
		i++;
	}
	line ^= 1;
}

void WriteLineTop(const char* message)
{
	
	SetDDRAM(0x00);
	
	int i = 0;
	while(message[i] != 0 && i < 16)
	{
		WriteRAM(message[i]);
		//_delay_ms(100);
		i++;
	}

}

void WriteLineBot(const char* message)
{
	
	SetDDRAM(0x40);
	
	int i = 0;
	while(message[i] != 0 && i < 16)
	{
		WriteRAM(message[i]);
		//_delay_ms(100);
		i++;
	}
	
}

void ResetSequence(void)
{
	DDRD = 0xFF; //open all PORTD outputs
	DDRB |= 0b11; //open PB0 and PB0 outputs
	DDRC |= (1 << 4); //move EN from PB4 to PC4 to prevent SPI collisions
	
	_delay_ms(1000);
	
	FunctionSetINIT();
	_delay_ms(5);
	FunctionSetINIT();
	_delay_us(200);
	FunctionSetINIT();
	_delay_us(200);
	
	FunctionSet(1, 1, 0);
	_delay_us(200);
	
	DisplayToggle(0, 0, 0);
	_delay_ms(5);
	
	EntryModeSet(1, 0);
	_delay_us(75);
	
	DisplayToggle(1, 0, 0);
	_delay_us(75);
}
