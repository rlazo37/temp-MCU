/*
 * spi.c
 *
 * Created: 12/5/2024 11:23:07 AM
 *  Author: ricar
 */ 

//#include "../Inc/spi.h"
#include <avr/io.h>

void SPISetup(void)
{
	//enable interrupts (automatically configures pins to their alt SPI function)
	
	SPCR |= (1 << SPIE);
	
	SPCR |= (1 << SPE);
	
	DDRB |= (1 << DDB4);
}